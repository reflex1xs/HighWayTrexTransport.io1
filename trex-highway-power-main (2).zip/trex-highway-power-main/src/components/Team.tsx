import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, UserCheck, Settings } from "lucide-react";

const Team = () => {
  const teamMembers = [
    {
      name: "Shahzad Khokhar",
      role: "Chief Executive Officer",
      icon: Crown,
      description: "Leading HighWay TREX Transport with vision and expertise in heavy machinery transportation industry.",
      color: "bg-gradient-to-br from-primary to-primary/80",
    },
    {
      name: "Ms. Hamna",
      role: "Manager",
      icon: UserCheck,
      description: "Overseeing daily operations and ensuring exceptional service delivery across all departments.",
      color: "bg-gradient-to-br from-secondary to-secondary/80",
    },
    {
      name: "Mr. Inshaal",
      role: "Operations Manager",
      icon: Settings,
      description: "Managing field operations, logistics coordination, and equipment deployment for optimal efficiency.",
      color: "bg-gradient-to-br from-accent to-accent/80",
    },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-industrial-dark mb-4">
            Our Leadership Team
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Meet the experts driving HighWay TREX Transport forward with dedication and industry expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <Card key={index} className="hover:shadow-industrial transition-all duration-300 border-2 hover:border-primary/20 overflow-hidden">
              <CardHeader className="text-center">
                <div className={`w-20 h-20 ${member.color} rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                  <member.icon className="h-10 w-10 text-industrial-white" />
                </div>
                <CardTitle className="text-xl text-industrial-dark">{member.name}</CardTitle>
                <Badge variant="secondary" className="mx-auto w-fit">
                  {member.role}
                </Badge>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  {member.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;