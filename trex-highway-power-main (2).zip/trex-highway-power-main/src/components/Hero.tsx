import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Truck, Users } from "lucide-react";
import heroImage from "@/assets/construction-hero.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-industrial-dark/80 via-primary/60 to-secondary/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-industrial-white mb-6 leading-tight">
            <span className="block">HighWay TREX</span>
            <span className="block text-3xl md:text-4xl lg:text-5xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Transport
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-industrial-white/90 mb-4 font-semibold">
            Driven by Power, Powered by Strength
          </p>
          
          <p className="text-lg md:text-xl text-industrial-white/80 mb-8 max-w-3xl mx-auto">
            Leading experts in heavy machinery transport, rental, and environmental solutions. 
            Your trusted partner for all industrial transportation needs.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-industrial">
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="bg-industrial-white/10 border-industrial-white text-industrial-white hover:bg-industrial-white hover:text-industrial-dark">
              Learn More
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-industrial-white/10 backdrop-blur-sm rounded-lg p-6 border border-industrial-white/20">
              <Shield className="h-8 w-8 text-primary mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-industrial-white mb-2">Safety First</h3>
              <p className="text-industrial-white/80 text-sm">Certified and insured operations</p>
            </div>
            <div className="bg-industrial-white/10 backdrop-blur-sm rounded-lg p-6 border border-industrial-white/20">
              <Truck className="h-8 w-8 text-secondary mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-industrial-white mb-2">Heavy Transport</h3>
              <p className="text-industrial-white/80 text-sm">Specialized equipment handling</p>
            </div>
            <div className="bg-industrial-white/10 backdrop-blur-sm rounded-lg p-6 border border-industrial-white/20">
              <Users className="h-8 w-8 text-primary mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-industrial-white mb-2">Expert Team</h3>
              <p className="text-industrial-white/80 text-sm">Professional service guaranteed</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;