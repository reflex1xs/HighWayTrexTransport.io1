import { Link } from "react-router-dom";
import { Truck, Mail, MapPin, Clock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-industrial-dark text-industrial-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="bg-primary p-2 rounded-lg">
                <Truck className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-lg font-bold">HighWay TREX</h3>
                <p className="text-sm text-industrial-white/80">Transport</p>
              </div>
            </div>
            <p className="text-industrial-white/80 text-sm">
              Driven by Power, Powered by Strength
            </p>
            <p className="text-industrial-white/70 text-sm">
              Your trusted partner for heavy machinery transport, rental, and environmental solutions.
            </p>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Services</h4>
            <ul className="space-y-2 text-sm text-industrial-white/80">
              <li>Heavy Machinery Transport</li>
              <li>Equipment Rental</li>
              <li>Environmental Solutions</li>
              <li>Technical Support</li>
              <li>Logistics Planning</li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-industrial-white/80 hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-industrial-white/80 hover:text-primary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold">Get In Touch</h4>
            <div className="space-y-3 text-sm text-industrial-white/80">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-primary" />
                <span>24/7 Service Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-primary" />
                <span>info@highwaytrex.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span>UAE Operations</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-industrial-white/20 mt-8 pt-8 text-center text-sm text-industrial-white/60">
          <p>&copy; 2024 HighWay TREX Transport. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;