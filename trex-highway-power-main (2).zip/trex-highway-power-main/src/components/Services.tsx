import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Truck, Wrench, Leaf, Users, Settings, MapPin } from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Truck,
      title: "Heavy Machinery Transport",
      description: "Safe and efficient transportation of heavy construction equipment, excavators, and industrial machinery across all terrains.",
    },
    {
      icon: Wrench,
      title: "Equipment Rental",
      description: "Comprehensive rental services for construction equipment, tankers, and specialized machinery with flexible terms.",
    },
    {
      icon: Leaf,
      title: "Environmental Solutions",
      description: "Eco-friendly transport and handling services with full environmental compliance and waste management.",
    },
    {
      icon: Settings,
      title: "Technical Support",
      description: "24/7 technical assistance and maintenance support for all transported and rental equipment.",
    },
    {
      icon: MapPin,
      title: "Logistics Planning",
      description: "Route optimization and logistics coordination for complex heavy machinery transportation projects.",
    },
    {
      icon: Users,
      title: "Expert Consultation",
      description: "Professional consultation services for industrial transportation challenges and project planning.",
    },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-industrial-dark mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive solutions for all your heavy machinery and transportation needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="hover:shadow-industrial transition-all duration-300 border-2 hover:border-primary/20">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mb-4">
                  <service.icon className="h-6 w-6 text-industrial-white" />
                </div>
                <CardTitle className="text-xl text-industrial-dark">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;