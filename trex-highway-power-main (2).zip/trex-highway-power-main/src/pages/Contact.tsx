import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Mail, MapPin, Clock, User } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Contact = () => {
  const contactInfo = [
    {
      name: "Shahzad Khokhar",
      role: "Chief Executive Officer",
      phone: "+971569122622",
      icon: User,
      color: "bg-primary",
    },
  ];

  const businessInfo = [
    {
      icon: Clock,
      title: "Business Hours",
      details: ["Monday - Friday: 24/7", "Weekend: Emergency Service", "Public Holidays: On Call"],
    },
    {
      icon: Mail,
      title: "Email",
      details: ["General: info@highwaytrex.com", "Operations: ops@highwaytrex.com", "Emergency: emergency@highwaytrex.com"],
    },
    {
      icon: MapPin,
      title: "Location",
      details: ["United Arab Emirates", "Serving Gulf Region", "Mobile Operations Available"],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-industrial-dark mb-4">
              Contact Us
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Get in touch with our team for all your heavy machinery transportation needs
            </p>
          </div>

          {/* Contact Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {/* Management Contact */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-industrial-dark mb-6">Management Team</h2>
              {contactInfo.map((contact, index) => (
                <Card key={index} className="hover:shadow-industrial transition-all duration-300 border-2 hover:border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 ${contact.color} rounded-full flex items-center justify-center`}>
                        <contact.icon className="h-6 w-6 text-industrial-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl text-industrial-dark">{contact.name}</CardTitle>
                        <CardDescription className="text-muted-foreground">{contact.role}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-3 mb-4">
                      <Phone className="h-5 w-5 text-primary" />
                      <span className="text-lg font-semibold text-industrial-dark">{contact.phone}</span>
                    </div>
                    <Button className="w-full bg-primary hover:bg-primary/90" asChild>
                      <a href={`tel:${contact.phone}`}>
                        <Phone className="h-4 w-4 mr-2" />
                        Call Now
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Business Information */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-industrial-dark mb-6">Business Information</h2>
              {businessInfo.map((info, index) => (
                <Card key={index} className="hover:shadow-industrial transition-all duration-300 border-2 hover:border-primary/20">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                        <info.icon className="h-5 w-5 text-industrial-white" />
                      </div>
                      <CardTitle className="text-lg text-industrial-dark">{info.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {info.details.map((detail, idx) => (
                        <li key={idx} className="text-muted-foreground flex items-center">
                          <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Emergency Contact Section */}
          <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-2 border-primary/20">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-industrial-dark mb-2">24/7 Emergency Service</CardTitle>
              <CardDescription className="text-lg">
                For urgent transportation needs and emergency situations
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="inline-flex items-center space-x-3 bg-primary/10 rounded-lg p-4 mb-6">
                <Phone className="h-6 w-6 text-primary" />
                <span className="text-xl font-bold text-industrial-dark">+971569122622</span>
              </div>
              <p className="text-muted-foreground mb-6">
                Available around the clock for critical machinery transport and emergency response
              </p>
              <Button size="lg" className="bg-primary hover:bg-primary/90 shadow-industrial" asChild>
                <a href="tel:+971569122622">
                  <Phone className="h-5 w-5 mr-2" />
                  Emergency Contact
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Contact;